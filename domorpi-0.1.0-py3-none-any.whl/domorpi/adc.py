"""DomoRPi ADC module"""

from __future__ import annotations

import logging
from . import DOMORPI_DUMMY

VBAT_CH = 0
VBAT_FACTOR = 2.736
ADC_SYSFS = '/sys/bus/iio/devices/iio:device0/'
ADC_RAW = 'in_voltage{0}_raw'
ADC_SCALE = 'in_voltage{0}_scale'

_LOGGER = logging.getLogger('domorpi.adc')
_LOGGER.setLevel(logging.DEBUG)

class DomoRpiAdc(object):
    def __init__(self):
        _LOGGER.info('ADC initialized')

    def ReadVBatt(self) -> float:
        if not DOMORPI_DUMMY:
            path = ADC_SYSFS + ADC_RAW.format(VBAT_CH)
            with open(path, 'r') as fp:
                raw = fp.read().strip()
            path = ADC_SYSFS + ADC_SCALE.format(VBAT_CH)
            with open(path, 'r') as fp:
                scale = fp.read().strip()
            return float(raw) * float(scale) * VBAT_FACTOR / 1000
        else:
            return 8.0            

