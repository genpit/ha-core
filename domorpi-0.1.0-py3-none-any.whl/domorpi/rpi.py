"""DomoRPi RPi module"""

from __future__ import annotations

import logging
import re
import subprocess
from . import DOMORPI_DUMMY

if not DOMORPI_DUMMY:
    from vcgencmd import Vcgencmd

_LOGGER = logging.getLogger('domorpi.rpi')
_LOGGER.setLevel(logging.DEBUG)

class DomoRpiRPi(object):
    def __init__(self):
        if not DOMORPI_DUMMY:
            self.vcgm = Vcgencmd()
        _LOGGER.info('RPi vcgencmd initialized')

    def readCoreTemperature(self) -> float:
        if not DOMORPI_DUMMY:
            return self.vcgm.measure_temp()
        else:
            return 50.0

    def readCoreVoltage(self) -> float:
        if not DOMORPI_DUMMY:
            return self.vcgm.measure_volts('core')
        else:
            return 0.888

    def readSerial(self) -> str:
        if not DOMORPI_DUMMY:
            command = "cat /proc/cpuinfo"
            all_info = subprocess.check_output(command, shell=True).decode().strip()
            for line in all_info.split("\n"):
                if "Serial" in line:
                    return re.sub(".*Serial.*: ", "", line,1)
        else:
            return "1234567890"                    
