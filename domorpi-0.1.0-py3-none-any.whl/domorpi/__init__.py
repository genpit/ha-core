"""domorpi module"""
from __future__ import annotations

import os

__version__ = "0.1.0"

DOMORPI_DUMMY = False
env = os.getenv('DOMORPI_DUMMY')
if env is not None and env == '1':
    DOMORPI_DUMMY = True
