"""DomoRPi GSM module"""

from __future__ import annotations

import serial
import fcntl, termios
import array
import logging
import time
import os
import signal
import re

from subprocess import Popen, PIPE, STDOUT
from . import DOMORPI_DUMMY

# https://github.com/babca/python-gsmmodem
if not DOMORPI_DUMMY:
    from gsmmodem.gprs import GprsModem, PdpContext
    from gsmmodem.modem import SentSms

DEFAULT_BAUDRATE = 115200

# XR21B1424 ioclt
XR_USB_SERIAL_SET_REG = 0x40007602  # dir=1 (<<30) | size=0 (<<16) | ch=0x76 (<<8) | nr=2 (<<0)
XR_USB_SERIAL_GET_REG = 0x80047601  # dir=2 (<<30) | size=4 (<<16) | ch=0x76 (<<8) | nr=1 (<<0)

# XR21B1424 registers
GPIO_MODE = 0x00c
GPIO_DIRECTION = 0x00d
GPIO_SET = 0x00e
GPIO_CLEAR = 0x00f
GPIO_STATE = 0x010
PIN_PULLUP = 0x014
PIN_PULLDOWN = 0x015

_LOGGER = logging.getLogger('domorpi.gsm')
_LOGGER.setLevel(logging.DEBUG)

class DomoRpiGsmModem(object):
    def __init__(self, port: string = '/dev/ttyUSB2', baudrate: int = DEFAULT_BAUDRATE, smsRxCallback=None):
        self._port = port
        self._baudrate = baudrate
        self._ppp_laddr = None
        self._ppp_raddr = None
        self._ppp_output = None
        self._ppp_proc = None
        self._is_connected = False
        self._modem = None
        self._smsRxCb = smsRxCallback
        _LOGGER.info('Initialized for port=%s baudrate=%d', self._port, self._baudrate)

    def poweron(self) -> int:
        if DOMORPI_DUMMY:
            return 0

        self._serline = serial.Serial(port=self._port, baudrate=DEFAULT_BAUDRATE)
        if self._serline.isOpen():
            _LOGGER.debug('Serial port opened')
        else:
            _LOGGER.error('Serial port not opened!')
            return -1

        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_MODE, 0x0001]))          # GPIO4 and GPIO5 are used for RTS/CTS, all other pins are used as GPIO
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_DIRECTION, 0x0003]))     # GPIO0 and GPIO1 output, GPIO2 input
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[PIN_PULLUP, 0x07FB]))         # Disable pullup on GPIO2
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[PIN_PULLDOWN, 0x0004]))       # Enable pulldown on GPIO2
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_CLEAR, 0x001]))          # GSM_PWREN# asserted
        time.sleep(0.5)
        buf = array.array('i',[GPIO_STATE, 0x0])
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_GET_REG, buf)
        if (buf[1] & 0x04):
            _LOGGER.debug('GSM module is already ON')
            self._serline.close()
            return 0
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0002]))           # GSM_PWRKEY asserted
        time.sleep(1.5)
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_CLEAR, 0x0002]))         # GSM_PWRKEY released
        buf = array.array('i',[GPIO_STATE, 0x0])
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_GET_REG, buf)
        count = 30
        while count > 0:
            buf = array.array('i',[GPIO_STATE, 0x0])
            fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_GET_REG, buf)
            if (buf[1] & 0x04):
                _LOGGER.debug('GSM module is ON')
                self._serline.close()
                return 0
            time.sleep(0.1)
            count -= 1
        _LOGGER.error('Failed to switch on the GSM module')
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0001]))           # GSM_PWREN# released
        self._serline.close()
        return -1

    def poweroff(self) -> int:
        if DOMORPI_DUMMY:
            return 0

        self._serline = serial.Serial(port=self._port, baudrate=DEFAULT_BAUDRATE)
        if self._serline.isOpen():
            _LOGGER.debug('Serial port opened')
        else:
            _LOGGER.error('Serial port not opened!')
            return -1

        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_MODE, 0x0001]))          # GPIO4 and GPIO5 are used for RTS/CTS, all other pins are used as GPIO
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_DIRECTION, 0x0003]))     # GPIO0 and GPIO1 output, GPIO2 input
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[PIN_PULLUP, 0x07FB]))         # Disable pullup on GPIO2
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[PIN_PULLDOWN, 0x0004]))       # Enable pulldown on GPIO2
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_CLEAR, 0x001]))          # GSM_PWREN# asserted
        time.sleep(0.5)
        buf = array.array('i',[GPIO_STATE, 0x0])
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_GET_REG, buf)
        if (buf[1] & 0x04) == 0:
            _LOGGER.debug('GSM module is already OFF')
            fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0001]))       # GSM_PWREN# released
            self._serline.close()
            return 0
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0002]))           # GSM_PWRKEY asserted
        time.sleep(1.5)
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_CLEAR, 0x0002]))         # GSM_PWRKEY released
        count = 30
        while count > 0:
            buf = array.array('i',[GPIO_STATE, 0x0])
            fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_GET_REG, buf)
            if (buf[1] & 0x04) == 0:
                _LOGGER.debug('GSM module is OFF')
                fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0001]))   # GSM_PWREN# released
                self._serline.close()
                return 0
            time.sleep(0.1)
            count -= 1
        _LOGGER.warn('Failed to switch off the GSM module - remove the power supply')
        fcntl.ioctl(self._serline.fd, XR_USB_SERIAL_SET_REG, array.array('i',[GPIO_SET, 0x0001]))           # GSM_PWREN# released
        self._serline.close()
        return 0

    def connect(self) -> int:
        if DOMORPI_DUMMY:
            return 0

        self.poweron()
        _LOGGER.debug('Initializing modem...')
        self._modem = GprsModem(self._port, self._baudrate, requestDelivery=False, smsReceivedCallbackFunc=self.handleRxSms)
        try:
            self._modem.connect(None)
        except:
            _LOGGER.error('GSM modem initialization failed')
            self._is_connected = False
            return -1
        else:
            _LOGGER.debug('GSM modem initialization completed')
            self._is_connected = True
            return 0

    def close(self) -> int:
        if DOMORPI_DUMMY:
            return 0

        if self._modem is not None:
            self._modem.close()
        _LOGGER.debug('GSM modem closed')
        self.poweroff()
        return 0

    def signalQuality(self) -> int:
        if DOMORPI_DUMMY:
            return 10

        if self._is_connected:
            return self._modem.signalStrength
        else:
            return -1

    def networkOperator(self) -> str | None:
        if DOMORPI_DUMMY:
            return None

        if self._is_connected:
            return self._modem.networkName
        else:
            return None    

    def handleRxSms(self, sms) -> int:
        if DOMORPI_DUMMY:
            return 0

        _LOGGER.info("SMS message received from: {0} - Time: {1} - Message: '{2}'".format(sms.number, sms.time, sms.text))
        if self._smsRxCb:
            self._smsRxCb(sms.number, sms.time, sms.text)
        return 0

    def sendSms(self, destination: str, text: str):
        if DOMORPI_DUMMY:
            return 0

        if self._is_connected is False:
            if self.connect() < 0:
                return -1
        _LOGGER.debug('Sending SMS to: {0}'.format(destination))
        try:
            response = self._modem.sendSms(destination, text)
        except:
            # :raise CommandError: if an error occurs while attempting to send the message
            # :raise TimeoutException: if the operation times out
            _LOGGER.error('Failed to send SMS')
        else:
            if type(response) == SentSms:
                _LOGGER.debug('SMS sent')
                return 0
            else:
                _LOGGER.error('SMS could not be sent')
        return -1

    def pppOn(self):
        if DOMORPI_DUMMY:
            return 0

        self._ppp_laddr = None
        self._ppp_raddr = None
        self._ppp_output = b''
        if self._is_connected is False:
            if self.connect() < 0:
                return -1
        _LOGGER.debug('Establishing GPRS connection')
        context = PdpContext(1,'IP','ibox.tim.it','0.0.0.0',0,0)
        try:
            self._modem.definePdpContext(context)
        except:
            _LOGGER.error('PDP context definition failed')
            return -1
        number='*99***1#'
        self._modem.write('ATDT{0};'.format(number), timeout=30, waitForResponse=False)
        _LOGGER.info('GPRS setup completed')
        commands = ['/usr/sbin/pppd', 'call', 'tim', 'nodetach']
        _LOGGER.debug('commands: %r', commands)
        self._ppp_proc = Popen(commands,
            stdout=PIPE,
            stderr=STDOUT,
            preexec_fn=os.setsid)

        # set stdout to non-blocking
        fd = self._ppp_proc.stdout.fileno()
        fl = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
        while True:
            try:
                data = self._ppp_proc.stdout.read()
                if data:
                    self._ppp_output += data
                    _LOGGER.debug('output: %r', self._ppp_output)
                    if not self._ppp_laddr:
                        result = re.search(b'local  IP address ([\d\.]+)', self._ppp_output)
                        if result:
                            self._ppp_laddr = result.group(1)
                            _LOGGER.debug('laddr: %s', self._ppp_laddr )
                    if not self._ppp_raddr:
                        result = re.search(b'remote IP address ([\d\.]+)', self._ppp_output)
                        if result:
                            self._ppp_raddr = result.group(1)
                            _LOGGER.debug('raddr: %s', self._ppp_raddr )

            except IOError as e:
                if e.errno != 11:
                    raise
                time.sleep(1)
            if self._ppp_laddr and self._ppp_raddr:
                _LOGGER.info('Connection established')
                return 0
            elif self._ppp_proc.poll():
                _LOGGER.error('PPP connection error %d (%s)', self._ppp_proc.returncode, self._ppp_output)
                return -1

    def pppOff(self):
        if DOMORPI_DUMMY:
            return 0

        os.killpg(os.getpgid(self._ppp_proc.pid), signal.SIGHUP)
        os.killpg(os.getpgid(self._ppp_proc.pid), signal.SIGTERM)
        self._ppp_laddr = None
        self._ppp_raddr = None
        self._ppp_proc = None
        _LOGGER.info('GPRS connection closed')
        return 0
