"""DomoRPi GPIO module"""

from __future__ import annotations

import logging
from . import DOMORPI_DUMMY

if not DOMORPI_DUMMY:
    import RPi.GPIO as GPIO

# RPi GPIO pins used on DomoRPi (BOARD mode)
VIN_FAULT = 16
BCHG_STAT = 18

_LOGGER = logging.getLogger('domorpi.gpio')
_LOGGER.setLevel(logging.DEBUG)

class DomoRpiGpio(object):
    def __init__(self):
        _LOGGER.info('GPIO initialized')
        if not DOMORPI_DUMMY:
            GPIO.setmode(GPIO.BOARD)
            GPIO.setup(VIN_FAULT, GPIO.IN)
            GPIO.setup(BCHG_STAT, GPIO.IN)

    def isVinFault(self) -> bool:
        if not DOMORPI_DUMMY:
            return GPIO.input(VIN_FAULT)==1
        else:
            return False    

    def isBatCharging(self) -> bool:
        if not DOMORPI_DUMMY:
            return GPIO.input(BCHG_STAT)==1
        else:
            return False